%define the initial value
T = 300;
kB = 1.380649e-23;
q = 1.602e-19;
alf = 1e-13;
I0 = 2.226217995701953e-14;
Rsh = 2021.5705009062435;
Iph = 0.025343763518385;
%import data
file = fullfile("PCE23.345.txt");
datatabel = importdata(file);
data = datatabel.data;
data = flipud(data);
%define V0,J0
V0 = data(:,1);
if data(1,2)<0
    J0 = data(:,2)*1e-3;
else
    J0 = -data(:,2)*1e-3;
end
%  function_1; b1：ideality factor yita=b1*kB*T/q  ; b2：Rs
f1= @(b1,b2,V) real(V/b2-Rsh*(b2*Iph+b2*I0+V)/(b2*(Rsh+b2))+(b1*kB*T/q)/b2*lambertw(1/(b1*kB*T/q)*b2*I0*Rsh/(b2+Rsh)*exp(1/(b1*kB*T/q)*Rsh*(b2*Iph+b2*I0+V)/(Rsh+b2))));
%calculation error and generate data
point_num = 300;
plt_data = ones(point_num^2, 3);
n = linspace(1, 2.5, point_num);
Rs = linspace(-10, 15, point_num);
sam_num = length(J0);
for i = 1 : point_num
    for j = 1 : point_num
        plt_data((i-1)*point_num+j, 1)=n(i);
        plt_data((i-1)*point_num+j, 2)=Rs(j);
        b = [n(i),Rs(j)];
        e_ini = 0;
        for k = 1 : sam_num
            e = (J0(k) - f1(b(1),b(2), V0(k)) )^2;
            e_ini = e_ini+e;
        end
        mse = e_ini/sam_num;
        plt_data((i-1)*point_num+j, 3) = log10(mse);
    end
end
%save data
save nid_Rs_MSE.txt -ascii plt_data

