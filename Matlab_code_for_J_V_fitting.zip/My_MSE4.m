function y=My_MSE4(b,V,J0)
global Rsh;  global Rsni;  global T; global kB;  global q; 
global alf; global Jsh0;global VOC;
% b0=[n0, I0, Iph];
b(2)=b(2)*alf;     % J0
nid=(Rsni-b(1))*(Jsh0-VOC/Rsh)/(kB*T/q);
yita=nid*kB*T/q;  %ideality factor*kBT/q;
Rs=b(1);  %Rs 


J=V./Rs...
    -Rsh*(Rs*b(3)+Rs*b(2)+V)/Rs/(Rsh+Rs)...
    +yita/Rs.*lambertw(1./yita*Rs*b(2)*Rsh/(Rs+Rsh).*...
    exp(1./yita*Rsh.*(Rs*b(3)+Rs*b(2)+V)./(Rsh+Rs)));
% J=-(-q*V+(-lambertw(q*b(2)*(Jsc-(Voc-b(2)*Jsc)/b(3))*exp(-q*Voc/(b(1) *kB*T))*b(3)/(b(2)*b(1)*kB...
% *T+b(3)*b(1)*kB*T)*exp(b(3)*q*(b(2)*(Jsc+b(2)*Jsc/b(3))+V)/b(1)/kB/T/(b(3)+b(2))))+b(3)*q*(b(2)...
% *(Jsc+b(2)*Jsc/b(3))+V)/b(1)/kB/T/(b(3)+b(2)))*b(1)*kB*T)/q/b(2);

yi=(J-J0).^2;
y=sum(yi)/length(yi);
end