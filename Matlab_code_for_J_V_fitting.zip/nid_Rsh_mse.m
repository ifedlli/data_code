%define the initial value
T = 300;
kB = 1.380649e-23;
q = 1.602e-19;
alf = 1e-13;
Rs = 1.8196229035913603;
I0 = 2.226217995701953e-14;
Iph = 0.025343763518385;
%import data
file = fullfile("PCE23.345.txt");
datatabel = importdata(file);
data = datatabel.data;
data = flipud(data);
%define V0,J0
V0 = data(:,1);
if data(1,2)<0
    J0 = data(:,2)*1e-3;
else
    J0 = -data(:,2)*1e-3;
end
%  function_1; b1：ideality factor yita=b1*kB*T/q  ; I0:b2
f1= @(b1,b2,V) real(V/Rs-b2*(Rs*Iph+Rs*I0+V)/(Rs*(b2+Rs))+(b1*kB*T/q)/Rs*lambertw(1/(b1*kB*T/q)*Rs*I0*b2/(Rs+b2)*exp(1/(b1*kB*T/q)*b2*(Rs*Iph+Rs*I0+V)/(b2+Rs))));
%calculation error and generate data
point_num = 300;
plt_data = ones(point_num^2, 3);
n = linspace(1, 2.5, point_num);
Rsh = linspace(-1000, 4000, point_num);
sam_num = length(J0);
for i = 1 : point_num
    for j = 1 : point_num
        plt_data((i-1)*point_num+j, 1)=n(i);
        plt_data((i-1)*point_num+j, 2)=Rsh(j);
        b = [n(i),Rsh(j)];
        e_ini = 0;
        for k = 1 : sam_num
            e = (J0(k) - f1(b(1),b(2), V0(k)) )^2;
            e_ini = e_ini+e;
        end
        mse = e_ini/sam_num;
        plt_data((i-1)*point_num+j, 3) = log10(mse);
    end
end
%save data
save nid_Rsh_MSE.txt -ascii plt_data

